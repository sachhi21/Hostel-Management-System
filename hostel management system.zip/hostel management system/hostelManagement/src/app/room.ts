export interface Room {
    [x: string]: any;
    roomNo: number;
    roomType: number;
    person1: boolean; 
    person2: boolean; 
    person3: boolean; 
}